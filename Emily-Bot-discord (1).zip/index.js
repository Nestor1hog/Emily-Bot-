require("./slash_commands.js") 

require("http").createServer((req, res) => res.end()).listen(process.env.PORT || 8080)

const Discord = require('discord.js');
const intents = new Discord.Intents(32767);                 
const client = new Discord.Client({ intents });
const akinator = require("discord.js-akinator");

const { DiscordTogether } = require('discord-together');

client.discordTogether = new DiscordTogether(client);

const fs = require('fs');
let { readdirSync } = require('fs'); 

client.commands = new Discord.Collection()
const commandFiles = fs.readdirSync("./comandos").filter(file => file.endsWith(".js"));
for (const file of commandFiles){
  const command = require(`./comandos/${file}`)
  client.commands.set(command.name, command)

const commandName = file.split(".")[0];
}

//////@@@@@@@@@

client.slashcommands = new Discord.Collection()

const slashComandos = fs.readdirSync("./Slash Commands").filter(file => file.endsWith(".js"))

for (const file of slashComandos){
    const slash = require(`./Slash Commands/${file}`)
  console.log(`Slash command ${file} cargado`)
  client.slashcommands.set(slash.data.name, slash)

}

client.on('interactionCreate', async (interaction) => { 

   if(!interaction.isCommand) return;

  const slashCons = client.slashcommands.get(interaction.commandName)

   if(!slashCons) return;
  try{
    await slashCons.execute(client, interaction)
  } catch(e){
    console.error(e)
  }
})


//////@@@@@@@@@

client.on("ready", () => {

  let status = [
    [{
      name: `.Help - Target 100 servers`,
      type: "PLAYING"
    }]
  ]
  setInterval(() => {
    function randomStatus() {
      let rstatus = status[Math.floor(Math.random() * status.length)];
      client.user.setPresence({ activities: rstatus, status: "online" });
    }
    randomStatus();
  });
  
}); 

  
///@@@@@@@@@


client.on('messageCreate', async message => { 
let prefix = ".";

  
if(message.channel.type === "dm") return;
if(message.author.bot)return;
if(!message.content.startsWith(prefix))return;
  
  const args = message.content.slice(prefix.length).trim().split(/ +/g)
  const command =  args.shift().toLowerCase()

let cmd = client.commands.find((c) => c.name === command || c.alias && c.alias.includes(command));

if(cmd){

const embed1 = new Discord.MessageEmbed()
  .setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
 .setColor("ffedd3")
 .setDescription(`Al parecer no tienes los suficientes permisos, Permiso nesesario **${cmd.userPerms || []}**`)
 .setFooter("Creado por Mr.Shiro!")

      const embed2 = new Discord.MessageEmbed()
  .setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
      .setColor("ffedd3")
  .setDescription(`Al parecer no tengo los suficientes permisos, Permiso nesesario **${cmd.botPerms || []}**`)
  .setFooter("Creado por Mr.Shiro!")


if(!message.member.permissions.has(cmd.userPerms || [])) return message.channel.send({ embeds: [embed1] })
 
if(!message.guild.me.permissions.has(cmd.botPerms || [])) return message.channel.send({ embeds: [embed2] })


  
}
    
if(cmd){
cmd.execute(client, message, args)
  

}  
})


client.login(process.env.TOKEN) 