
const Discord = require('discord.js');

module.exports = {
  name: "ppt",
  alias: ["rps"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

const { RockPaperScissors } = require("sudo-minigames")

const embed1 = new Discord.MessageEmbed()
.setTitle("\⛔ • Algo salio mal")
.setDescription("No mencionaste a nadie")
.setColor("ffedd3")
.setFooter("Creado por Mr.Shiro!")
.setTimestamp()

  
const embed2 = new Discord.MessageEmbed()
.setTitle("\⛔ • Algo salio mal")
.setDescription("No puedes jugar contigo mismo")
.setColor("ffedd3")
.setFooter("Creado por Mr.Shiro!")
.setTimestamp()
  
const usuario = message.mentions.members.first()
if(!usuario) return message.reply({ embeds: [embed1] })
  
if(usuario.id === message.author.id) return message.reply({ embeds: [embed2] })





await RockPaperScissors({
	message: message,
	opponent: message.mentions.users.first(),
	embed: {
		title: '<:emoji_36:948743606863282196> • Minijuego: Un juego tipico ppt, diviertete.',
		description: 'Presiona el botón de abajo para elegir tu elemento.',
		color: '#ffedd3',
		footer: 'Creado por Mr.Shiro!',
		timestamp: true,
	},
	buttons: {
		rock: '🪨 Piedra',
		paper: '📃 Hoja',
		scissors: '✂️ Tijera',
		accept: 'Aceptar',
		deny: 'Negar',
	},
	time: 60000,
	acceptMessage:
		'<@{{challenger}}> ha desafiado <@{{opponent}}> para un juego de ¡Piedra, Papel y Tijeras!',
	winMessage: 'Wow, <@{{winner}}> ¡Gano!',
	drawMessage: '¡este juego esta empatado!',
	endMessage: "<@{{opponent}}> no respondió a tiempo. Entonces, ¡se cerro el juego!",
	timeEndMessage:
		"Ambos no eligieron algo a tiempo. Entonces, ¡se cerro el juego!",
	cancelMessage:
		'<@{{opponent}}> ¡Se negó a jugar contigo un juego de piedra, papel o tijera!',
	choseMessage: 'Elegiste {{emoji}}',
	noChangeMessage: '¡No puede cambiar su selección!',
	othersMessage: '¡Solo {{author}} puede usar los botones!',
});
  
 }

} 
