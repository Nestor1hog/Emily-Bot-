const Discord = require('discord.js');

module.exports = {
  name: "guess-number",
  alias: ["gn"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

const { GuessTheNumber } = require("sudo-minigames")

await GuessTheNumber({
	message: message,
	embed: {
		title: '<:emoji_36:948743606863282196> • Minijuego: Adivina el numero aleatorio ( 1 - 10 ).',
		description: 'Tienes **{{time}}** para adivinar el número.',
		color: '#ffedd3',
        footer: 'Creado por Mr.Shiro!',
		timestamp: true
	},
	publicGame: true,
	number: (Math.floor(Math.random() * 10 + 1)  
),
	time: 60000,
	winMessage: {
		publicGame:
			'GG, el número que adiviné era **{{number}}**. <@{{winner}}> lo hizo en **{{time}}**.\n\n__**Estadísticas del juego:**__\n**Duration**: {{time}}\n**Número de participantes**: {{totalparticipants}} Participantes\n**Participantes**: {{participants}}',
		privateGame:
			'GG, el número que adiviné era **{{number}}**. Lo hiciste en **{{time}}**.',
	},
	loseMessage:
		'¡Mejor suerte la próxima vez! El número que adiviné era **{{number}}**.',
	bigNumberMessage: 'No {{author}}! mi número es mayor que **{{number}}**.',
	smallNumberMessage:
		'No {{author}}! Mi número es más pequeño que **{{number}}**.',
	othersMessage: 'Solamente{} <@{{author}}> puede utilizar los botones!',
	buttonText: 'Cancel',
	ongoingMessage:
		"Ya se está ejecutando un juego <#{{channel}}>. ¡No puedes empezar uno nuevo!",
});
  
 }

} 
