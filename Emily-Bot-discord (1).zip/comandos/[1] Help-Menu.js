const Discord = require('discord.js');
const owner = "Mr.Shiro!"

module.exports = {
  name: "help",
  alias: ["ayuda"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
  
async execute (client, message, args){

const row = new Discord.MessageActionRow()
.addComponents(
new Discord.MessageSelectMenu()
.setCustomId("M1")
.setMaxValues(1)
.addOptions([
  {
  label: "Infomación",
  description: "Aprende acerca de Emily.",
  value: "info",
  emoji: "<:emoji_34:948741683997196318>"
  },
  {
  label: "Acción",
  description: "¡Interactua! con Emily u otro usuario.",
  value: "acc",
  emoji: "<:emoji_33:948741656683880468>"
  },
    {
  label: "Reacción",
  description: "¡Rolea! con los demas usuarios.",
  value: "ecc",
  emoji: "<:emoji_35:948741711260184586>"
    },
    {
  label: "Anime",
  description: "Busca, Investiga entre otras cosas.",
  value: "ani",
  emoji: "<:emoji_36:948743606863282196>"
    },
    {
  label: "MiniGame",
  description: "Divierte con juegos y minijuegos de Emily.",
  value: "div",
  emoji: "<:emoji_37:948744635390509097>"
    },
    {
  label: "Nsfw",
  description: "Comandos +18 ",
  value: "nsfw",
  emoji: "<:emoji_38:951631634850000916>"
    },
    {
  label: "Extras",
  description: "Comandos de sobra.",
  value: "ex",
  emoji: "<:emoji_32:948741633254502421>"
    }
])
  )
  


const embed1 = new Discord.MessageEmbed()
.setTitle("<:emoji_34:948741683997196318> • Información")
.setDescription(`¡Hola!, Soy Emily una bot de diversión en fase de prueba mi prefijo es .`)
.setColor("#ffedd3 ")
.setFooter(`Creado por ${owner}`)
  .setTimestamp()
  
const embed2 = new Discord.MessageEmbed()
.setTitle("<:emoji_33:948741656683880468> • Acción")
.setDescription(`\`\`\`
• Abrazar      • Comida        • Escapar
• Acariciar    • Cosquillas    • Guiño
• Besar        • Disparar      • Golpear
• Cachetada    • Enfadado      • Insultar
• Lamer        • Molestar      • Perseguir
• Matar        • Palma         • Dedomalo
• Mirar        • Patear        • Apuñalar
\`\`\``) 
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
    .setTimestamp() 
  
const embed3 = new Discord.MessageEmbed()
.setTitle("<:emoji_35:948741711260184586> • Reaccion")
.setDescription(`Estos son los siguientes comandos:`)
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
  .setTimestamp()
  
const embed4 = new Discord.MessageEmbed()
.setTitle("<:emoji_36:948743606863282196> • Anime")
.setDescription(`Estos son los siguientes comandos:`)
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
    .setTimestamp()
  
const embed5 = new Discord.MessageEmbed()
.setTitle("<:emoji_37:948744635390509097> • MiniGames")
.setDescription("Estos son los siguientes comandos:\n`\📟 • calculator`\n`\🔢 • guess-number`\n`\🐍 • snake`\n`\🧞‍♂️ • Akinator`")
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
  .setTimestamp()
  
const embed6 = new Discord.MessageEmbed()
.setTitle("<:emoji_32:948741633254502421> • Extras")
.setDescription("Estos son los siguientes comandos:\n`• vc-yt`")
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
  .setTimestamp() 

  const embed7 = new Discord.MessageEmbed()
.setTitle("<:emoji_38:951631634850000916> • Nsfw")
.setDescription("Estos son los siguientes comandos:")
.setColor("#ffedd3")
.setFooter(`Creado por ${owner}`)
  .setTimestamp() 
  

const m = await message.channel.send({ embeds: [embed1], components: [row] })

const ifilter = i => i.user.id === message.author.id;

const collector = m.createMessageComponentCollector({ filter: ifilter, time: 60000})




collector.on("collect", async i => {
  if(i.values[0] === "info"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed1], components: [row] })  
  }
  if(i.values[0] === "acc"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed2], components: [row] })  
  }
  if(i.values[0] === "ecc"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed3], components: [row] }) 
  }
  if(i.values[0] === "ani"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed4], components: [row] })
  }
   if(i.values[0] === "div"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed5], components: [row] })
   }
   if(i.values[0] === "nsfw"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed7], components: [row] })
   }
   if(i.values[0] === "ex"){
  await i.deferUpdate()
  i.editReply({ embeds: [embed6], components: [row] })
  }
   })

}
      }