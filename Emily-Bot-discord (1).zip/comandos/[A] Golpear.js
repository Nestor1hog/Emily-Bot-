const Discord = require('discord.js');

module.exports = {
  name: "golpear",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
execute (client, message, args){

const Anime_Images = require('anime-images-api')
const API = new Anime_Images()


  
async function getIMG(){
    let { image } = await API.sfw.punch()
    
const usuario = message.mentions.members.first()



  
    const emb = new Discord.MessageEmbed()
  .setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
      .setColor("ffedd3")
  .setDescription("Al parecer no mencionaste a alguien para golpear")
  .setFooter("Creado por Mr.Shiro!")

if(!usuario) return message.channel.send({ embeds: [emb] })


  const em = new Discord.MessageEmbed()
.setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
    .setColor("ffedd3")
.setDescription("No puedes golpearte a ti mismo, Nesesitas a alguien")
.setFooter("Creado por Mr.Shiro!")

if(usuario.id === message.author.id) return message.channel.send({ embeds: [em] })

let aA = message.author
let aB = message.mentions.users.first()

 

  

const embed = new Discord.MessageEmbed()
.setDescription(`**<:emoji_34:948741683997196318> • ${aA} Acaba de golpear a ${aB}**`)
 .setImage(`${image}`)
  .setColor("ffedd3")
  .setFooter("Creado por Mr.Shiro!")
  
  message.channel.send({ embeds: [embed] })
}
  getIMG()
  
 }

} 
