const Discord = require('discord.js');

module.exports = {
  name: "guiño",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){
  
  const Anime_Images = require('anime-images-api')
const API = new Anime_Images()
async function getIMG(){
    let { image } = await API.sfw.wink()
    

const usuario = message.mentions.members.first()
let aA = message.author
let aB = message.mentions.users.first()



  const em = new Discord.MessageEmbed()
    .setColor("ffedd3")
.setDescription(`<:emoji_34:948741683997196318>** • ${aA} Esta guiñando**`)
    .setImage(image)
.setFooter("Creado por Mr.Shiro!")

if(!usuario) return message.channel.send({ embeds: [em] })

if(usuario.id === message.author.id) return message.channel.send({ embeds: [em] })

const embed = new Discord.MessageEmbed()
.setDescription(`**<:emoji_34:948741683997196318> • ${aA} Le esta guiñando a ${aB}**`)
 .setImage(image)
  .setColor("ffedd3")
  .setFooter("Creado por Mr.Shiro!")
  
  message.channel.send({ embeds: [embed] }) 
 

}
getIMG()
  
 }

}
