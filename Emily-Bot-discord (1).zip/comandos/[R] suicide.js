const Discord = require('discord.js');

module.exports = {
  name: "suicide",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

const star = require("star-labs")
  
let aA = message.author

const embed = new Discord.MessageEmbed()
.setDescription(`**<:emoji_32:948741633254502421> • ${aA} Se ah matado**`)
 .setImage(star.suicide())
  .setColor("ffedd3")
  .setFooter("Creado por Mr.Shiro!")
  
  message.channel.send({ embeds: [embed] }) 
 }

} 
