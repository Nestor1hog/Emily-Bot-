const Discord = require('discord.js');

module.exports = {
  name: "c",
  alias: ["calculator"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

 const { Calculator } = require("sudo-minigames");
  
await Calculator({
    message: message,
    embed: {
        title: '<:emoji_36:948743606863282196> • MiniJuego: Calculadora Matemáticas Profesional.',
       color: '#ffedd3',
        footer: 'Creado por Mr.Shiro!'
    },
    disabledQuery: '¡Calculadora apagada!',
    invalidQuery: '¡La siguente ecuacion es inexistente!',
    othersMessage: '¡Solo <@{{author}}> puede usar los botones!'
});

 }

} 
