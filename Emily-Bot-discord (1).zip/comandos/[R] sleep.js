const Discord = require('discord.js');

module.exports = {
  name: "sleep",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

const star = require("star-labs")
  
let aA = message.author

const embed = new Discord.MessageEmbed()
.setDescription(`**<:emoji_34:948741683997196318> • ${aA} Esta durmiendo owo **`)
 .setImage(star.sleep())
  .setColor("ffedd3")
  .setFooter("Creado por Mr.Shiro!")
  
  message.channel.send({ embeds: [embed] }) 
 }

} 
