const Discord = require('discord.js');

module.exports = {
  name: "snake",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

 const { Snake } = require("sudo-minigames");

  await Snake({
	message: message,
	embed: {
		title: '<:emoji_36:948743606863282196> • Minijuego: Simulador del Videojuego de la Serpiente.',
		description: 'Wow, Alcanzaste un numero de **{{score}}** puntos!',
		color: '#ffedd3',
        footer: 'Creado por MrShiro!',
		timestamp: true
	},
	emojis: {
		empty: '⬛',
		snakeBody: '🟨',
		food: '🍎',
		up: '⬆️',
		right: '⬅️',
		down: '⬇️',
		left: '➡️',
	},
	othersMessage: '¡Solo <@{{author}}> puede usar los botones!',
	buttonText: 'Cancel'
});
  
 }

} 
