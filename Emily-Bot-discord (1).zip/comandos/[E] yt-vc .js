const Discord = require('discord.js');

module.exports = {
  name: "yt-vc",
  alias: ["yt"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
execute (client, message, args){

const embed = new Discord.MessageEmbed()
.setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
.setColor("ffedd3")
.setDescription("No estás en un canal de voz")
.setFooter("Creado por Mr.Shiro!")

  
if(!message.member.voice.channel) return message.channel.send({ embeds: [embed] })

  
client.discordTogether.createTogetherCode(message.member.voice.channel.id, 'youtube').then(async invite => {
    return message.channel.send(`${invite.code}`);
});
  
 }

} 
