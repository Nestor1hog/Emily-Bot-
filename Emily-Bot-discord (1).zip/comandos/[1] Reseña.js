const Discord = require('discord.js');

module.exports = {
  name: "reseña",
  alias: [],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
execute (client, message, args){

message.delete()

const reseña = args.join(" ")
if(!reseña) return message.channel.send({ embeds: [embed] })

const embed = new Discord.MessageEmbed()
.setTitle("")

client.channel.cache.get("951695597239406592").send({ embeds: [embed] })

 }

} 
