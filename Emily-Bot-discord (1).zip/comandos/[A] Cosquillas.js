const Discord = require('discord.js');

module.exports = {
  name: "cosquilla",
  alias: ["cosquillas"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
async execute (client, message, args){

const { soyultro } = require("soyultro");
let Gifs = soyultro("tickle");
  
const usuario = message.mentions.members.first()
let aA = message.author
let aB = message.mentions.users.first()


    const emb = new Discord.MessageEmbed()
  .setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
      .setColor("ffedd3")
  .setDescription("Al parecer no mencionaste a alguien para hacerle cosquillas")
  .setFooter("Creado por Mr.Shiro!")

if(!usuario) return message.channel.send({ embeds: [emb] })


  const em = new Discord.MessageEmbed()
.setTitle("<:emoji_32:948741633254502421> • Algo salio mal.")
    .setColor("ffedd3")
.setDescription("No puedes hacerte cosquillas, Nesesitas a alguien")
.setFooter("Creado por Mr.Shiro!")

if(usuario.id === message.author.id) return message.channel.send({ embeds: [em] })


  
  

const embed = new Discord.MessageEmbed()
.setDescription(`**<:emoji_34:948741683997196318> • ${aA} Le esta haciendo cosquillas a ${aB}**`)
 .setImage(Gifs)
  .setColor("ffedd3")
  .setFooter("Creado por Mr.Shiro!")
  
  message.channel.send({ embeds: [embed] }) 
 }

} 
