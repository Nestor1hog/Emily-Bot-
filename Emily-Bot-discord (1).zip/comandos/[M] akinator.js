const Discord = require('discord.js');

module.exports = {
  name: "akinator",
  alias: ["aki"],
  userPerms: [],
  botPerms: ["ADMINISTRATOR"],
execute (client, message, args){

const akinator = require("discord.js-akinator");  

  const language = "es"; 
const childMode = false; 
const gameType = "character"; 
const useButtons = true; 
const embedColor = "#ffedd3"; 


  akinator(message, {
            language: language, 
            childMode: childMode,
            gameType: gameType,
            useButtons: useButtons, 
            embedColor: embedColor 
        });

 }

} 